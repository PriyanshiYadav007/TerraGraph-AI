"""Deterministic local ingestion with provenance and quarantine reporting."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .models import SchemaError, validate_record


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_sha256(value: Any) -> str:
    encoded = json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def load_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def ingest_records(path: Path) -> dict[str, Any]:
    raw = load_json(path)
    if not isinstance(raw, list):
        raise ValueError("Raw listings root must be a JSON array")

    accepted: list[dict[str, Any]] = []
    quarantined: list[dict[str, Any]] = []
    accepted_record_ids: dict[str, int] = {}
    for index, record in enumerate(raw):
        try:
            validated = validate_record(record)
            record_id = validated["record_id"]
            if record_id in accepted_record_ids:
                quarantined.append(
                    {
                        "recordId": record_id,
                        "rowIndex": index,
                        "reason": "duplicate_record_id",
                        "errors": [
                            f"record_id duplicates accepted row {accepted_record_ids[record_id]}"
                        ],
                        "action": "quarantined; excluded from normalization and ranking",
                    }
                )
                continue
            accepted_record_ids[record_id] = index
            accepted.append({**validated, "raw_record_sha256": canonical_sha256(validated)})
        except SchemaError as exc:
            quarantined.append(
                {
                    "recordId": exc.record_id,
                    "rowIndex": index,
                    "reason": "schema_validation_failed",
                    "errors": exc.errors,
                    "action": "quarantined; excluded from normalization and ranking",
                }
            )

    return {
        "accepted": accepted,
        "quarantined": quarantined,
        "manifest": {
            "path": "data/raw/listings.json",
            "sha256": sha256_file(path),
            "rowsSeen": len(raw),
            "rowsAccepted": len(accepted),
            "rowsQuarantined": len(quarantined),
            "schemaVersion": "1.0",
        },
    }
