"""Strict input contracts for synthetic food-and-agriculture listings.

The project intentionally uses a small, dependency-free validator instead of
silently coercing fields.  That makes malformed upstream values visible and
keeps the demo runnable with only scikit-learn installed.
"""

from __future__ import annotations

from datetime import date, datetime
import math
import re
from typing import Any


SCHEMA_VERSION = "1.0"

RECORD_KEYS = {
    "schema_version",
    "record_id",
    "record_type",
    "organization_name",
    "organization_type",
    "product_name",
    "description",
    "category",
    "quantity",
    "unit",
    "price_per_unit",
    "currency",
    "location",
    "available_from",
    "available_until",
    "certifications",
    "required_certifications",
    "attributes",
    "claims",
    "reliability_score",
    "source",
}

LOCATION_KEYS = {"city", "state", "country", "latitude", "longitude"}
SOURCE_KEYS = {
    "connector",
    "source_ref",
    "source_uri",
    "captured_at",
    "consent_basis",
    "synthetic",
}

ORGANIZATION_TYPES = {
    "farmer",
    "cooperative",
    "processor",
    "buyer",
    "distributor",
    "institution",
}
UNITS = {"kg", "lb", "metric_ton"}
CURRENCIES = {"USD"}
RECORD_ID_RE = re.compile(r"^(SUP|DEM|BAD)-\d{3}$")


class SchemaError(ValueError):
    """Raised when an input record fails the versioned data contract."""

    def __init__(self, record_id: str, errors: list[str]):
        self.record_id = record_id
        self.errors = errors
        super().__init__(f"{record_id}: " + "; ".join(errors))


def _is_number(value: Any) -> bool:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(float(value))
    except (OverflowError, ValueError):
        return False


def _parse_iso_date(value: Any, field: str, errors: list[str]) -> date | None:
    if not isinstance(value, str):
        errors.append(f"{field} must be an ISO-8601 calendar date")
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        errors.append(f"{field} must be an ISO-8601 calendar date (YYYY-MM-DD)")
        return None


def _parse_iso_datetime(value: Any, field: str, errors: list[str]) -> datetime | None:
    if not isinstance(value, str):
        errors.append(f"{field} must be an ISO-8601 timestamp")
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        errors.append(f"{field} is not a valid ISO-8601 timestamp")
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        errors.append(f"{field} must include a UTC offset or Z")
        return None
    return parsed


def _require_exact_keys(
    obj: Any, expected: set[str], field: str, errors: list[str]
) -> bool:
    if not isinstance(obj, dict):
        errors.append(f"{field} must be an object")
        return False
    missing = sorted(expected - set(obj))
    extra = sorted(set(obj) - expected)
    if missing:
        errors.append(f"{field} missing keys: {', '.join(missing)}")
    if extra:
        errors.append(f"{field} has unknown keys: {', '.join(extra)}")
    return not missing and not extra


def _require_text(record: dict[str, Any], field: str, errors: list[str]) -> None:
    value = record.get(field)
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{field} must be a non-empty string")


def _require_string_list(
    record: dict[str, Any], field: str, errors: list[str]
) -> None:
    value = record.get(field)
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item.strip() for item in value
    ):
        errors.append(f"{field} must be a list of non-empty strings")


def validate_record(record: Any) -> dict[str, Any]:
    """Validate one listing without coercion and return it unchanged.

    Exact-key validation is deliberate: upstream schema drift is quarantined
    rather than being silently discarded.
    """

    record_id = record.get("record_id", "unknown") if isinstance(record, dict) else "unknown"
    errors: list[str] = []
    if not _require_exact_keys(record, RECORD_KEYS, "record", errors):
        if not isinstance(record, dict):
            raise SchemaError(record_id, errors)

    if record.get("schema_version") != SCHEMA_VERSION:
        errors.append(f"schema_version must equal {SCHEMA_VERSION}")
    if not isinstance(record_id, str) or not RECORD_ID_RE.fullmatch(record_id):
        errors.append("record_id must match (SUP|DEM|BAD)-NNN")
    if record.get("record_type") not in {"supply", "demand"}:
        errors.append("record_type must be supply or demand")
    if record.get("organization_type") not in ORGANIZATION_TYPES:
        errors.append("organization_type is not recognized")
    for field in (
        "organization_name",
        "product_name",
        "description",
        "category",
    ):
        _require_text(record, field, errors)

    for field in ("quantity", "reliability_score"):
        if not _is_number(record.get(field)):
            errors.append(f"{field} must be numeric (no string coercion)")
    if _is_number(record.get("quantity")) and record["quantity"] <= 0:
        errors.append("quantity must be greater than zero")
    price = record.get("price_per_unit")
    if price is not None and not _is_number(price):
        errors.append("price_per_unit must be numeric or null (no string coercion)")
    if _is_number(price) and price <= 0:
        errors.append("price_per_unit must be greater than zero when provided")
    if _is_number(record.get("reliability_score")) and not 0 <= record["reliability_score"] <= 1:
        errors.append("reliability_score must be between 0 and 1")
    if record.get("unit") not in UNITS:
        errors.append(f"unit must be one of {sorted(UNITS)}")
    if record.get("currency") not in CURRENCIES:
        errors.append("currency must be USD in this demo")

    start = _parse_iso_date(record.get("available_from"), "available_from", errors)
    end = _parse_iso_date(record.get("available_until"), "available_until", errors)
    if start and end and start > end:
        errors.append("available_from must not be after available_until")

    for field in ("certifications", "required_certifications", "claims"):
        _require_string_list(record, field, errors)
    attributes = record.get("attributes")
    if not isinstance(attributes, dict) or any(
        not isinstance(key, str)
        or not (isinstance(value, (str, bool)) or _is_number(value))
        for key, value in (attributes.items() if isinstance(attributes, dict) else [])
    ):
        errors.append("attributes must be a flat object of finite scalar values")

    location = record.get("location")
    if _require_exact_keys(location, LOCATION_KEYS, "location", errors):
        for field in ("city", "state", "country"):
            if not isinstance(location[field], str) or not location[field].strip():
                errors.append(f"location.{field} must be a non-empty string")
        for field, lower, upper in (
            ("latitude", -90, 90),
            ("longitude", -180, 180),
        ):
            value = location[field]
            if not _is_number(value) or not lower <= value <= upper:
                errors.append(f"location.{field} must be in [{lower}, {upper}]")

    source = record.get("source")
    if _require_exact_keys(source, SOURCE_KEYS, "source", errors):
        for field in ("connector", "source_ref", "source_uri", "consent_basis"):
            if not isinstance(source[field], str) or not source[field].strip():
                errors.append(f"source.{field} must be a non-empty string")
        _parse_iso_datetime(source["captured_at"], "source.captured_at", errors)
        if source["synthetic"] is not True:
            errors.append("source.synthetic must be true for this demo dataset")
        if not source["source_uri"].startswith("synthetic://"):
            errors.append("source.source_uri must use synthetic:// in demo mode")

    if errors:
        raise SchemaError(str(record_id), errors)
    return record
