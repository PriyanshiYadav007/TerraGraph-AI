"""Explainable scikit-learn ranking for supply-demand candidates."""

from __future__ import annotations

import csv
from datetime import date
import math
from pathlib import Path
from typing import Any

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


FEATURES = [
    "semantic_similarity",
    "product_exact",
    "distance_score",
    "volume_coverage",
    "price_fit",
    "certification_fit",
    "season_overlap",
    "evidence_quality",
]

FEATURE_LABELS = {
    "semantic_similarity": "Product-language similarity",
    "product_exact": "Canonical product agreement",
    "distance_score": "Geographic proximity",
    "volume_coverage": "Requested volume coverage",
    "price_fit": "Price ceiling fit",
    "certification_fit": "Certification evidence fit",
    "season_overlap": "Availability-window overlap",
    "evidence_quality": "Derived evidence quality",
}


def _read_training(path: Path) -> tuple[np.ndarray, np.ndarray, list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    expected = {*FEATURES, "manual_review_decision", "review_id", "label_origin"}
    if not rows or set(rows[0]) != expected:
        raise ValueError("Reviewed match history does not match the expected feature contract")
    matrix = np.asarray([[float(row[name]) for name in FEATURES] for row in rows])
    labels = np.asarray([int(row["manual_review_decision"]) for row in rows])
    return matrix, labels, rows


def train_ranker(path: Path) -> tuple[Pipeline, dict[str, Any]]:
    """Train a real sklearn model and measure deterministic out-of-fold ranking quality."""

    x_train, y_train, rows = _read_training(path)
    estimator = Pipeline(
        [
            ("scale", StandardScaler()),
            (
                "model",
                LogisticRegression(
                    C=0.55,
                    solver="liblinear",
                    random_state=42,
                    class_weight="balanced",
                ),
            ),
        ]
    )
    folds = StratifiedKFold(n_splits=6, shuffle=True, random_state=42)
    out_of_fold_scores = cross_val_predict(
        estimator, x_train, y_train, cv=folds, method="predict_proba"
    )[:, 1]
    out_of_fold_decisions = (out_of_fold_scores >= 0.5).astype(int)
    estimator.fit(x_train, y_train)

    scaler: StandardScaler = estimator.named_steps["scale"]
    model: LogisticRegression = estimator.named_steps["model"]
    coefficients = [
        {
            "feature": feature,
            "label": FEATURE_LABELS[feature],
            "standardizedCoefficient": round(float(coefficient), 4),
            "direction": "raises rank" if coefficient >= 0 else "lowers rank",
        }
        for feature, coefficient in zip(FEATURES, model.coef_[0], strict=True)
    ]
    report = {
        "algorithm": "StandardScaler + LogisticRegression",
        "implementation": "scikit-learn",
        "trainingRows": int(len(rows)),
        "positiveRows": int(y_train.sum()),
        "negativeRows": int(len(y_train) - y_train.sum()),
        "featureCount": len(FEATURES),
        "features": FEATURES,
        "validation": {
            "method": "6-fold stratified out-of-fold evaluation on the synthetic fixture",
            "rocAuc": round(float(roc_auc_score(y_train, out_of_fold_scores)), 3),
            "averagePrecision": round(float(average_precision_score(y_train, out_of_fold_scores)), 3),
            "f1AtPoint5": round(float(f1_score(y_train, out_of_fold_decisions)), 3),
        },
        "coefficients": coefficients,
        "intercept": round(float(model.intercept_[0]), 4),
        "featureMeans": {
            name: round(float(value), 4)
            for name, value in zip(FEATURES, scaler.mean_, strict=True)
        },
        "labelDisclosure": (
            "Labels are manually curated synthetic scenario decisions, not observed trades "
            "and not domain-expert validated. Metrics measure this tiny fixture only."
        ),
        "scoreDisclosure": (
            "fitScore is a relative ranking signal derived from model output. It is not a "
            "probability of a transaction, an accuracy claim, or an autonomous decision."
        ),
    }
    return estimator, report


def haversine_km(left: dict[str, Any], right: dict[str, Any]) -> float:
    radius_km = 6371.0088
    lat1, lon1 = math.radians(left["latitude"]), math.radians(left["longitude"])
    lat2, lon2 = math.radians(right["latitude"]), math.radians(right["longitude"])
    delta_lat, delta_lon = lat2 - lat1, lon2 - lon1
    value = (
        math.sin(delta_lat / 2) ** 2
        + math.cos(lat1) * math.cos(lat2) * math.sin(delta_lon / 2) ** 2
    )
    return radius_km * 2 * math.atan2(math.sqrt(value), math.sqrt(1 - value))


def _date_overlap(supply: dict[str, Any], demand: dict[str, Any]) -> float:
    supply_start = date.fromisoformat(supply["available_from"])
    supply_end = date.fromisoformat(supply["available_until"])
    demand_start = date.fromisoformat(demand["available_from"])
    demand_end = date.fromisoformat(demand["available_until"])
    overlap = max(0, (min(supply_end, demand_end) - max(supply_start, demand_start)).days + 1)
    demand_days = (demand_end - demand_start).days + 1
    return min(1.0, overlap / demand_days)


def _semantic_scores(pairs: list[tuple[dict[str, Any], dict[str, Any]]]) -> list[float]:
    if not pairs:
        return []
    documents: list[str] = []
    for supply, demand in pairs:
        documents.extend(
            [
                f"{supply['product_name_raw']} {supply['description']} {supply['canonical_product_name']}",
                f"{demand['product_name_raw']} {demand['description']} {demand['canonical_product_name']}",
            ]
        )
    matrix = TfidfVectorizer(ngram_range=(1, 2), stop_words="english").fit_transform(documents)
    return [
        float(cosine_similarity(matrix[i * 2], matrix[i * 2 + 1])[0, 0])
        for i in range(len(pairs))
    ]


def _certification_fit(supply: dict[str, Any], demand: dict[str, Any]) -> float:
    required = set(demand["required_certifications"])
    if not required:
        return 1.0
    assertions = {item["name"]: item for item in supply["certification_assertions"]}
    if not required.issubset(assertions):
        return 0.0
    if any(assertions[name]["evidenceRef"] is None for name in required):
        return 0.5
    return 1.0


def build_candidates(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    supplies = [r for r in records if r["record_type"] == "supply"]
    demands = [r for r in records if r["record_type"] == "demand"]
    pairs = [
        (supply, demand)
        for supply in supplies
        for demand in demands
        if supply["canonical_product_id"] == demand["canonical_product_id"]
        and supply["product_resolution_decision"] == "accepted"
        and demand["product_resolution_decision"] == "accepted"
    ]
    semantic_scores = _semantic_scores(pairs)
    candidates: list[dict[str, Any]] = []
    for index, ((supply, demand), semantic) in enumerate(zip(pairs, semantic_scores, strict=True), 1):
        distance = haversine_km(supply["location"], demand["location"])
        distance_score = 1.0 / (1.0 + distance / 900.0)
        volume_coverage = min(1.0, supply["quantity_kg"] / demand["quantity_kg"])
        if supply["price_per_kg"] is None or demand["price_per_kg"] is None:
            price_fit = 0.5
            price_note = "price missing on one side; neutral placeholder used"
        else:
            price_fit = min(1.0, demand["price_per_kg"] / supply["price_per_kg"])
            price_note = "buyer ceiling compared with supplier ask after unit normalization"
        cert_fit = _certification_fit(supply, demand)
        season_overlap = _date_overlap(supply, demand)
        evidence_quality = (supply["derived_data_quality_score"] + demand["derived_data_quality_score"]) / 2
        vector = {
            "semantic_similarity": round(semantic, 6),
            "product_exact": 1.0,
            "distance_score": round(distance_score, 6),
            "volume_coverage": round(volume_coverage, 6),
            "price_fit": round(price_fit, 6),
            "certification_fit": round(cert_fit, 6),
            "season_overlap": round(season_overlap, 6),
            "evidence_quality": round(evidence_quality, 6),
        }
        candidates.append(
            {
                "id": f"OPP-{index:03d}",
                "supply": supply,
                "demand": demand,
                "distanceKm": round(distance, 1),
                "featureVector": vector,
                "featureNotes": {
                    "price_fit": price_note,
                    "quantity_basis": demand["quantity_basis"],
                    "certification_fit": "assertion and evidence presence only; no live registry verification",
                },
            }
        )
    return candidates


def rank_candidates(
    candidates: list[dict[str, Any]], estimator: Pipeline
) -> list[dict[str, Any]]:
    if not candidates:
        return []
    matrix = np.asarray(
        [[candidate["featureVector"][name] for name in FEATURES] for candidate in candidates]
    )
    scores = estimator.predict_proba(matrix)[:, 1]
    scaler: StandardScaler = estimator.named_steps["scale"]
    model: LogisticRegression = estimator.named_steps["model"]
    standardized = scaler.transform(matrix)
    for row_index, (candidate, score) in enumerate(zip(candidates, scores, strict=True)):
        contributions = standardized[row_index] * model.coef_[0]
        ranked = sorted(
            zip(FEATURES, contributions, strict=True),
            key=lambda item: abs(item[1]),
            reverse=True,
        )
        candidate["fitScore"] = round(float(score) * 100, 1)
        candidate["scoreLabel"] = "relative model ranking score — not a probability"
        candidate["drivers"] = [
            {
                "feature": feature,
                "label": FEATURE_LABELS[feature],
                "value": round(candidate["featureVector"][feature], 3),
                "contribution": round(float(contribution), 3),
                "effect": "raises rank" if contribution >= 0 else "lowers rank",
            }
            for feature, contribution in ranked[:4]
        ]
    candidates.sort(key=lambda item: (-item["fitScore"], item["id"]))
    for rank, candidate in enumerate(candidates, 1):
        candidate["rank"] = rank
    return candidates

