"""Unit, text, evidence, and lineage normalization."""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
import re
from typing import Any


KG_PER_UNIT = {"kg": 1.0, "lb": 0.45359237, "metric_ton": 1000.0}
SNAPSHOT_AT = datetime(2026, 8, 20, 0, 0, tzinfo=timezone.utc)


def normalize_text(value: str) -> str:
    return " ".join(re.sub(r"[^a-z0-9]+", " ", value.lower()).split())


def _evidence_index(rows: list[dict[str, Any]]) -> dict[str, dict[str, dict[str, Any]]]:
    result: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
    for row in rows:
        result[row["record_id"]][row["certification"]] = row
    return result


def _certification_assertions(
    record: dict[str, Any], evidence: dict[str, dict[str, dict[str, Any]]]
) -> list[dict[str, Any]]:
    assertions = []
    for certification in record["certifications"]:
        item = evidence.get(record["record_id"], {}).get(certification)
        assertions.append(
            {
                "name": certification,
                "assertedBySource": True,
                "evidenceStatus": (
                    item["evidence_status"] if item else "asserted_without_evidence"
                ),
                "evidenceRef": item.get("evidence_ref") if item else None,
                "realWorldVerified": False,
            }
        )
    return assertions


def _derived_quality(
    record: dict[str, Any], assertions: list[dict[str, Any]]
) -> tuple[float, list[dict[str, Any]]]:
    """Build a transparent data-quality score; never trust the source score as truth."""

    checks = {
        "schema_valid": 0.35,
        "provenance_complete": 0.20,
        "fresh_capture": 0.10,
        "price_present": 0.10 if record["price_per_unit"] is not None else 0.0,
        "attributes_present": 0.10 if len(record["attributes"]) >= 2 else 0.05,
        "cert_evidence_present": 0.15,
    }
    captured = datetime.fromisoformat(record["source"]["captured_at"].replace("Z", "+00:00"))
    if (SNAPSHOT_AT - captured).days > 30:
        checks["fresh_capture"] = 0.02
    if assertions and any(item["evidenceRef"] is None for item in assertions):
        checks["cert_evidence_present"] = 0.05
    if not assertions:
        checks["cert_evidence_present"] = 0.10
    score = round(sum(checks.values()), 3)
    maximums = {
        "schema_valid": 0.35,
        "provenance_complete": 0.20,
        "fresh_capture": 0.10,
        "price_present": 0.10,
        "attributes_present": 0.10,
        "cert_evidence_present": 0.15,
    }
    components: list[dict[str, Any]] = []
    for name, awarded in checks.items():
        possible = maximums[name]
        if name == "cert_evidence_present" and not assertions:
            status = "not_applicable_neutral_credit"
        elif awarded == possible:
            status = "pass"
        elif awarded == 0:
            status = "fail"
        else:
            status = "partial"
        components.append(
            {
                "name": name,
                "awardedWeight": awarded,
                "possibleWeight": possible,
                "status": status,
            }
        )
    return min(score, 1.0), components


def normalize_records(
    records: list[dict[str, Any]], evidence_rows: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    evidence = _evidence_index(evidence_rows)
    normalized: list[dict[str, Any]] = []
    for record in records:
        factor = KG_PER_UNIT[record["unit"]]
        assertions = _certification_assertions(record, evidence)
        quality_score, quality_components = _derived_quality(record, assertions)
        source_ref = record["source"]["source_ref"]
        canonical = {
            "record_id": record["record_id"],
            "record_type": record["record_type"],
            "organization_name_raw": record["organization_name"],
            "organization_name_normalized": normalize_text(record["organization_name"]),
            "organization_type": record["organization_type"],
            "product_name_raw": record["product_name"],
            "description": record["description"],
            "category_raw": record["category"],
            "quantity_original": record["quantity"],
            "unit_original": record["unit"],
            "quantity_kg": round(record["quantity"] * factor, 3),
            "quantity_basis": "total available/requested across stated availability window",
            "price_original": record["price_per_unit"],
            "price_per_kg": (
                round(record["price_per_unit"] / factor, 4)
                if record["price_per_unit"] is not None
                else None
            ),
            "price_basis": (
                f"USD per {record['unit']}" if record["price_per_unit"] is not None else "not supplied"
            ),
            "currency": record["currency"],
            "location": record["location"],
            "location_precision": "synthetic exact demo coordinate; not a real operating location",
            "available_from": record["available_from"],
            "available_until": record["available_until"],
            "certification_assertions": assertions,
            "required_certifications": record["required_certifications"],
            "attributes": record["attributes"],
            "practice_claims": [
                {
                    "claim": claim,
                    "status": "source_assertion_not_independently_verified",
                }
                for claim in record["claims"]
            ],
            "source_asserted_reliability": record["reliability_score"],
            "derived_data_quality_score": quality_score,
            "derived_quality_components": quality_components,
            "provenance": {
                **record["source"],
                "rawRecordSha256": record["raw_record_sha256"],
            },
            "field_lineage": {
                "quantity_kg": {
                    "sourceRef": source_ref,
                    "sourceFields": ["quantity", "unit"],
                    "transform": f"quantity * {factor} kg/{record['unit']}",
                },
                "price_per_kg": {
                    "sourceRef": source_ref,
                    "sourceFields": ["price_per_unit", "unit", "currency"],
                    "transform": "price_per_unit / kg_per_unit; null preserved",
                },
                "certification_assertions": {
                    "sourceRef": source_ref,
                    "sourceFields": ["certifications"],
                    "evidenceRefs": [
                        item["evidenceRef"] for item in assertions if item["evidenceRef"]
                    ],
                },
                "location": {
                    "sourceRef": source_ref,
                    "sourceFields": ["location"],
                    "transform": "none; synthetic demo fixture",
                },
            },
        }
        normalized.append(canonical)
    return normalized
