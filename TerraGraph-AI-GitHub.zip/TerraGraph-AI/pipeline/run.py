"""Run TerraGraph AI end to end and publish dashboard-ready JSON.

Usage from the repository root::

    python -m pipeline.run

The run performs no network calls and uses a fixed demo snapshot so identical
inputs and dependency versions produce identical JSON artifacts.
"""

from __future__ import annotations

from collections import Counter
import json
from pathlib import Path
from typing import Any

from .entity_resolution import resolve_organizations, resolve_products
from .graph import build_graph
from .guardrails import apply_guardrails
from .ingest import ingest_records, load_json, sha256_file
from .normalize import normalize_records
from .quality import build_quality_findings
from .ranker import build_candidates, rank_candidates, train_ranker


ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT_AT = "2026-08-20T00:00:00+05:30"


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, sort_keys=False)
        handle.write("\n")


def _agent_trace(
    manifest: dict[str, Any],
    accepted: int,
    quarantined: int,
    product_audit: list[dict[str, Any]],
    org_merges: list[dict[str, Any]],
    candidates: list[dict[str, Any]],
    graph: dict[str, Any],
) -> list[dict[str, Any]]:
    rows = [
        ("discover", "Source Discovery Agent", "read versioned local connector fixtures", manifest["rowsSeen"], manifest["rowsSeen"], f"input sha256 {manifest['sha256'][:12]}…"),
        ("validate", "Schema Guard Agent", "enforce exact-key and type contract", manifest["rowsSeen"], accepted, f"accepted {accepted}; quarantined {quarantined}"),
        ("normalize", "Normalization Agent", "standardize units while preserving raw values and nulls", accepted, accepted, "kg and USD/kg canonical fields with field lineage"),
        ("evidence", "Evidence Agent", "separate source assertions from evidence references", accepted, accepted, "no certification marked real-world verified"),
        ("resolve", "Entity Resolution Agent", "resolve taxonomy and organization aliases with TF-IDF", accepted, accepted, f"{sum(item['decision'] == 'accepted' for item in product_audit)} product mappings accepted; {len(org_merges)} alias merges"),
        ("rank", "Opportunity Ranker", "train sklearn model and rank same-product candidates", accepted, len(candidates), f"{len(candidates)} candidates scored as relative ranking signals"),
        ("guard", "Policy Guard Agent", "apply certification, evidence, completeness, date, and human-review gates", len(candidates), len(candidates), "zero automatic commercial actions"),
        ("graph", "Knowledge Graph Agent", "materialize typed nodes, relations, capabilities, and evidence refs", len(candidates), len(graph["edges"]), f"{len(graph['nodes'])} nodes; {len(graph['edges'])} edges"),
        ("publish", "Audit Publisher", "emit deterministic dashboard and audit artifacts", len(graph["edges"]), 1, "public/data/dashboard.json"),
    ]
    return [
        {
            "stage": index,
            "stageId": stage_id,
            "agent": agent,
            "operation": operation,
            "status": "completed",
            "inputCount": input_count,
            "outputCount": output_count,
            "decision": decision,
            "eventAt": f"2026-08-20T00:{index:02d}:00+05:30",
            "executionMode": "deterministic offline module; no external model or API call",
        }
        for index, (stage_id, agent, operation, input_count, output_count, decision) in enumerate(rows, 1)
    ]


def _display_quantity(quantity_kg: float) -> str:
    if quantity_kg >= 1000:
        return f"{quantity_kg / 1000:,.0f} t"
    return f"{quantity_kg:,.0f} kg"


def _public_opportunity(candidate: dict[str, Any]) -> dict[str, Any]:
    supply, demand = candidate["supply"], candidate["demand"]
    matched_quantity = min(supply["quantity_kg"], demand["quantity_kg"])
    return {
        "id": candidate["id"],
        "rank": candidate["rank"],
        "fitScore": candidate["fitScore"],
        "scoreLabel": candidate["scoreLabel"],
        "status": candidate["status"],
        "statusLabel": candidate["statusLabel"],
        "humanDecisionRequired": True,
        "product": {
            "id": supply["canonical_product_id"],
            "name": supply["canonical_product_name"],
            "category": supply["canonical_category"],
            "supplierRawName": supply["product_name_raw"],
            "buyerRawName": demand["product_name_raw"],
        },
        "supplier": {
            "organizationId": supply["organization_entity_id"],
            "name": supply["organization_canonical_name"],
            "recordId": supply["record_id"],
            "location": f"{supply['location']['city']}, {supply['location']['state']}",
            "quantityKg": supply["quantity_kg"],
            "quantityDisplay": _display_quantity(supply["quantity_kg"]),
            "askUsdPerKg": supply["price_per_kg"],
            "derivedDataQuality": supply["derived_data_quality_score"],
            "sourceRef": supply["provenance"]["source_ref"],
        },
        "buyer": {
            "organizationId": demand["organization_entity_id"],
            "name": demand["organization_canonical_name"],
            "recordId": demand["record_id"],
            "location": f"{demand['location']['city']}, {demand['location']['state']}",
            "quantityKg": demand["quantity_kg"],
            "quantityDisplay": _display_quantity(demand["quantity_kg"]),
            "ceilingUsdPerKg": demand["price_per_kg"],
            "derivedDataQuality": demand["derived_data_quality_score"],
            "sourceRef": demand["provenance"]["source_ref"],
        },
        "route": f"{supply['location']['city']}, {supply['location']['state']} → {demand['location']['city']}, {demand['location']['state']}",
        "distanceKm": candidate["distanceKm"],
        "matchedQuantityKg": matched_quantity,
        "matchedQuantityDisplay": _display_quantity(matched_quantity),
        "quantityBasis": demand["quantity_basis"],
        "availability": {
            "supplier": [supply["available_from"], supply["available_until"]],
            "buyer": [demand["available_from"], demand["available_until"]],
        },
        "requiredCertifications": demand["required_certifications"],
        "supplierCertificationAssertions": supply["certification_assertions"],
        "featureVector": candidate["featureVector"],
        "featureNotes": candidate["featureNotes"],
        "drivers": candidate["drivers"],
        "guardrails": candidate["guardrails"],
        "provenance": {
            "supplierSourceRef": supply["provenance"]["source_ref"],
            "buyerSourceRef": demand["provenance"]["source_ref"],
            "supplierRawSha256": supply["provenance"]["rawRecordSha256"],
            "buyerRawSha256": demand["provenance"]["rawRecordSha256"],
        },
    }


def _public_record(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "recordId": record["record_id"],
        "recordType": record["record_type"],
        "organizationId": record["organization_entity_id"],
        "organizationRaw": record["organization_name_raw"],
        "organizationCanonical": record["organization_canonical_name"],
        "organizationType": record["organization_type"],
        "productRaw": record["product_name_raw"],
        "productCanonical": record["canonical_product_name"],
        "canonicalProductId": record["canonical_product_id"],
        "productResolution": {
            "method": record["product_resolution_method"],
            "score": record["product_resolution_score"],
            "decision": record["product_resolution_decision"],
        },
        "quantityKg": record["quantity_kg"],
        "quantityBasis": record["quantity_basis"],
        "priceUsdPerKg": record["price_per_kg"],
        "priceBasis": record["price_basis"],
        "availability": [record["available_from"], record["available_until"]],
        "location": record["location"],
        "locationDisclosure": record["location_precision"],
        "certificationAssertions": record["certification_assertions"],
        "practiceClaims": record["practice_claims"],
        "sourceAssertedReliability": record["source_asserted_reliability"],
        "derivedDataQualityScore": record["derived_data_quality_score"],
        "derivedDataQualityComponents": record["derived_quality_components"],
        "source": record["provenance"],
        "fieldLineage": record["field_lineage"],
    }


def build_dashboard(root: Path = ROOT) -> tuple[dict[str, Any], dict[str, Any]]:
    raw_path = root / "data/raw/listings.json"
    taxonomy_path = root / "data/reference/products.json"
    evidence_path = root / "data/reference/certification_evidence.json"
    history_path = root / "data/reference/reviewed_match_history.csv"

    ingested = ingest_records(raw_path)
    taxonomy = load_json(taxonomy_path)
    evidence = load_json(evidence_path)
    normalized = normalize_records(ingested["accepted"], evidence)
    normalized, product_audit = resolve_products(normalized, taxonomy)
    normalized, org_merges = resolve_organizations(normalized)
    estimator, model_report = train_ranker(history_path)
    candidates = rank_candidates(build_candidates(normalized), estimator)
    candidates, compliance = apply_guardrails(candidates)
    quality_findings = build_quality_findings(
        normalized, ingested["quarantined"], org_merges, product_audit
    )
    graph = build_graph(normalized, taxonomy, candidates)
    trace = _agent_trace(
        ingested["manifest"],
        len(normalized),
        len(ingested["quarantined"]),
        product_audit,
        org_merges,
        candidates,
        graph,
    )

    run_id = f"TG-{ingested['manifest']['sha256'][:12].upper()}"
    source_counts = Counter(record["provenance"]["connector"] for record in normalized)
    organization_nodes = [n for n in graph["nodes"] if n["type"] == "Organization"]
    product_nodes = [n for n in graph["nodes"] if n["type"] == "Product"]
    capability_nodes = [n for n in graph["nodes"] if n["type"] == "Capability"]
    fit_scores = [candidate["fitScore"] for candidate in candidates]
    dashboard = {
        "meta": {
            "project": "TerraGraph AI",
            "tagline": "Evidence-aware opportunity intelligence for a more connected food system",
            "runId": run_id,
            "generatedAt": SNAPSHOT_AT,
            "schemaVersion": "dashboard-1.0",
            "executionMode": "deterministic offline demo",
            "demoDisclosure": (
                "Every organization, listing, transaction scenario, source reference, evidence "
                "reference, and coordinate in this project is fictional synthetic demo data."
            ),
            "locationDisclosure": "Exact coordinates are synthetic visualization fixtures and do not represent real facilities.",
            "scoreDisclosure": model_report["scoreDisclosure"],
            "inputSha256": ingested["manifest"]["sha256"],
        },
        "summary": {
            "recordsScanned": ingested["manifest"]["rowsSeen"],
            "validatedRecords": len(normalized),
            "quarantinedRecords": len(ingested["quarantined"]),
            "supplyListings": sum(r["record_type"] == "supply" for r in normalized),
            "demandListings": sum(r["record_type"] == "demand" for r in normalized),
            "canonicalProducts": len(product_nodes),
            "organizationEntities": len(organization_nodes),
            "organizationAliasesMerged": len(org_merges),
            "opportunityCandidates": len(candidates),
            "reviewReady": compliance["counts"]["review-ready"],
            "needsEvidence": compliance["counts"]["needs-evidence"],
            "blocked": compliance["counts"]["blocked"],
            "meanFitScore": round(sum(fit_scores) / len(fit_scores), 1) if fit_scores else 0,
            "meanDerivedDataQuality": round(
                sum(r["derived_data_quality_score"] for r in normalized) / len(normalized), 3
            ),
            "knowledgeGraphNodes": len(graph["nodes"]),
            "knowledgeGraphEdges": len(graph["edges"]),
            "automaticActionsTaken": 0,
        },
        "opportunities": [_public_opportunity(candidate) for candidate in candidates],
        "records": [_public_record(record) for record in normalized],
        "entities": {
            "organizations": organization_nodes,
            "products": product_nodes,
            "processorCapabilities": capability_nodes,
        },
        "knowledgeGraph": graph,
        "qualityFindings": quality_findings,
        "quarantine": ingested["quarantined"],
        "complianceGuardrails": compliance,
        "agentTrace": trace,
        "modelCard": {
            **model_report,
            "intendedUse": "Prioritize fictional supply-demand candidates for human investigation.",
            "notIntendedFor": [
                "autonomous procurement or contracting",
                "certificate or regulatory verification",
                "credit, pricing, legal, or investment decisions",
                "claims about real organizations, supply, demand, or impact",
            ],
            "limitations": [
                "Only 48 manually curated synthetic examples; no observed transaction outcomes.",
                "Out-of-fold metrics describe this small fixture and do not establish production performance.",
                "The relative fit score is not calibrated and is not a transaction probability or accuracy measure.",
                "Certification evidence references are fictional; live registries are not queried.",
                "Distance is straight-line distance between fictional coordinates, not a logistics quote or route.",
                "The demo does not model perishability, freight capacity, counterparty risk, or contract terms.",
                "No fairness, drift, calibration, or external validation has been completed.",
            ],
        },
        "methodology": [
            {"step": 1, "name": "Ingest", "detail": "Read consent-tagged synthetic connector fixtures and hash the input."},
            {"step": 2, "name": "Validate", "detail": "Apply exact versioned schemas; quarantine instead of coercing."},
            {"step": 3, "name": "Normalize", "detail": "Convert units, preserve nulls and raw values, attach field lineage."},
            {"step": 4, "name": "Resolve", "detail": "Use TF-IDF char n-grams for product aliases and organization identities."},
            {"step": 5, "name": "Rank", "detail": "Train an explainable sklearn model on labeled synthetic scenarios."},
            {"step": 6, "name": "Guard", "detail": "Block or route candidates based on evidence, dates, and completeness."},
            {"step": 7, "name": "Graph", "detail": "Link organizations, products, regions, assertions, and processor capabilities."},
            {"step": 8, "name": "Audit", "detail": "Publish decisions, hashes, inputs, outputs, disclosures, and limitations."},
        ],
        "sourceCatalog": [
            {
                "connector": connector,
                "recordCount": count,
                "mode": "local synthetic fixture",
                "networkUsed": False,
                "consent": "fixture includes an explicit consent_basis",
            }
            for connector, count in sorted(source_counts.items())
        ],
    }
    artifacts = {
        "normalized": normalized,
        "productAudit": product_audit,
        "organizationMerges": org_merges,
        "modelReport": model_report,
        "graph": graph,
        "agentTrace": trace,
        "quarantine": ingested["quarantined"],
        "manifest": {
            **ingested["manifest"],
            "runId": run_id,
            "taxonomySha256": sha256_file(taxonomy_path),
            "evidenceRegistrySha256": sha256_file(evidence_path),
            "trainingHistorySha256": sha256_file(history_path),
        },
    }
    return dashboard, artifacts


def write_artifacts(root: Path, dashboard: dict[str, Any], artifacts: dict[str, Any]) -> None:
    processed = root / "data/processed"
    _write_json(processed / "normalized_records.json", artifacts["normalized"])
    _write_json(
        processed / "entity_resolution_audit.json",
        {
            "productMappings": artifacts["productAudit"],
            "organizationMerges": artifacts["organizationMerges"],
        },
    )
    _write_json(processed / "model_report.json", artifacts["modelReport"])
    _write_json(processed / "knowledge_graph.json", artifacts["graph"])
    _write_json(processed / "agent_audit_log.json", artifacts["agentTrace"])
    _write_json(processed / "quarantine.json", artifacts["quarantine"])
    _write_json(processed / "run_manifest.json", artifacts["manifest"])
    _write_json(root / "public/data/dashboard.json", dashboard)
    _write_json(root / "app/dashboard-data.json", dashboard)


def main() -> None:
    dashboard, artifacts = build_dashboard(ROOT)
    write_artifacts(ROOT, dashboard, artifacts)
    summary = dashboard["summary"]
    validation = dashboard["modelCard"]["validation"]
    print(
        "TerraGraph AI pipeline complete: "
        f"{summary['validatedRecords']} valid / {summary['quarantinedRecords']} quarantined; "
        f"{summary['opportunityCandidates']} candidates; "
        f"OOF ROC-AUC={validation['rocAuc']:.3f}; "
        "wrote public/data/dashboard.json"
    )


if __name__ == "__main__":
    main()
