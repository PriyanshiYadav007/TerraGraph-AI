"""TF-IDF resolution for product taxonomy and organization identities."""

from __future__ import annotations

from collections import defaultdict
import hashlib
import re
from typing import Any

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .normalize import normalize_text


ORG_STOPWORDS = {
    "co",
    "company",
    "coop",
    "cooperative",
    "inc",
    "llc",
    "laboratories",
    "laboratory",
    "labs",
}


def _org_key(name: str) -> str:
    tokens = [token for token in normalize_text(name).split() if token not in ORG_STOPWORDS]
    # Northstar and North Star are deliberately brought onto the same comparison surface.
    return "".join(tokens)


def _stable_id(prefix: str, value: str) -> str:
    return f"{prefix}-{hashlib.sha1(value.encode('utf-8')).hexdigest()[:10].upper()}"


def resolve_products(
    records: list[dict[str, Any]], taxonomy: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    documents: list[str] = []
    alias_sets: list[set[str]] = []
    for item in taxonomy:
        aliases = {normalize_text(item["name"]), *(normalize_text(a) for a in item["aliases"])}
        alias_sets.append(aliases)
        documents.append(" ".join(sorted(aliases)) + " " + item["description"])

    queries = [
        f"{r['product_name_raw']} {r['description']} {r['category_raw']}" for r in records
    ]
    vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=1)
    matrix = vectorizer.fit_transform(documents + queries)
    scores = cosine_similarity(matrix[len(documents) :], matrix[: len(documents)])
    audit: list[dict[str, Any]] = []
    for row_index, record in enumerate(records):
        raw_key = normalize_text(record["product_name_raw"])
        exact_candidates = [i for i, aliases in enumerate(alias_sets) if raw_key in aliases]
        if exact_candidates:
            best = exact_candidates[0]
            method = "exact_normalized_alias"
            confidence = 1.0
        else:
            best = int(scores[row_index].argmax())
            method = "tfidf_char_ngrams"
            confidence = float(scores[row_index, best])
        decision = "accepted" if confidence >= 0.58 else "manual_review"
        match = taxonomy[best]
        record.update(
            {
                "canonical_product_id": match["product_id"],
                "canonical_product_name": match["name"],
                "canonical_category": match["category"],
                "product_resolution_score": round(confidence, 4),
                "product_resolution_method": method,
                "product_resolution_decision": decision,
            }
        )
        record["field_lineage"]["canonical_product_id"] = {
            "sourceRef": record["provenance"]["source_ref"],
            "sourceFields": ["product_name", "description", "category"],
            "transform": f"{method} against data/reference/products.json",
        }
        audit.append(
            {
                "recordId": record["record_id"],
                "rawValue": record["product_name_raw"],
                "canonicalValue": match["name"],
                "canonicalProductId": match["product_id"],
                "score": round(confidence, 4),
                "method": method,
                "decision": decision,
            }
        )
    return records, audit


def resolve_organizations(
    records: list[dict[str, Any]], threshold: float = 0.72
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    names = [record["organization_name_raw"] for record in records]
    comparison = [_org_key(name) for name in names]
    vectorizer = TfidfVectorizer(analyzer="char", ngram_range=(2, 4), min_df=1)
    matrix = vectorizer.fit_transform(comparison)
    similarities = cosine_similarity(matrix)

    parent = list(range(len(records)))

    def find(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    def union(left: int, right: int) -> None:
        left_root, right_root = find(left), find(right)
        if left_root != right_root:
            parent[max(left_root, right_root)] = min(left_root, right_root)

    candidate_pairs: list[dict[str, Any]] = []
    for left in range(len(records)):
        for right in range(left + 1, len(records)):
            same_place = (
                records[left]["location"]["city"] == records[right]["location"]["city"]
                and records[left]["location"]["state"] == records[right]["location"]["state"]
            )
            same_role = records[left]["record_type"] == records[right]["record_type"]
            score = float(similarities[left, right])
            accepted = same_place and same_role and score >= threshold
            if accepted:
                union(left, right)
                candidate_pairs.append(
                    {
                        "leftRecordId": records[left]["record_id"],
                        "rightRecordId": records[right]["record_id"],
                        "score": round(score, 4),
                        "decision": "merged",
                        "evidence": ["tfidf_name_similarity", "same_city_state", "same_market_side"],
                    }
                )

    groups: dict[int, list[int]] = defaultdict(list)
    for index in range(len(records)):
        groups[find(index)].append(index)

    for indexes in groups.values():
        # First listing is the canonical display name; every alias remains auditable.
        canonical_name = records[min(indexes)]["organization_name_raw"]
        entity_id = _stable_id("ORG", normalize_text(canonical_name))
        for index in indexes:
            records[index]["organization_entity_id"] = entity_id
            records[index]["organization_canonical_name"] = canonical_name
            records[index]["organization_aliases"] = sorted({names[i] for i in indexes})
            records[index]["field_lineage"]["organization_entity_id"] = {
                "sourceRef": records[index]["provenance"]["source_ref"],
                "sourceFields": ["organization_name", "location.city", "location.state"],
                "transform": "TF-IDF char n-gram clustering with same-place and same-side constraints",
            }
    return records, candidate_pairs

