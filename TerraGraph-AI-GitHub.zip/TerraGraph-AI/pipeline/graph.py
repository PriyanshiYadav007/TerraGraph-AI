"""Build a compact, typed food-and-agriculture knowledge graph."""

from __future__ import annotations

from collections import defaultdict
import hashlib
from typing import Any


def _id(prefix: str, value: str) -> str:
    return f"{prefix}-{hashlib.sha1(value.encode('utf-8')).hexdigest()[:10].upper()}"


def build_graph(
    records: list[dict[str, Any]],
    taxonomy: list[dict[str, Any]],
    opportunities: list[dict[str, Any]],
) -> dict[str, Any]:
    nodes: dict[str, dict[str, Any]] = {}
    edges: list[dict[str, Any]] = []
    organization_records: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        organization_records[record["organization_entity_id"]].append(record)

    for organization_id, listings in sorted(organization_records.items()):
        first = listings[0]
        sides = sorted({item["record_type"] for item in listings})
        nodes[organization_id] = {
            "id": organization_id,
            "type": "Organization",
            "label": first["organization_canonical_name"],
            "organizationType": first["organization_type"],
            "marketSide": sides[0] if len(sides) == 1 else "both",
            "region": f"{first['location']['city']}, {first['location']['state']}",
            "aliases": sorted({alias for item in listings for alias in item["organization_aliases"]}),
            "listingCount": len(listings),
            "meanDerivedDataQuality": round(
                sum(item["derived_data_quality_score"] for item in listings) / len(listings), 3
            ),
            "synthetic": True,
        }
        region_id = f"REGION-US-{first['location']['state']}"
        nodes.setdefault(
            region_id,
            {
                "id": region_id,
                "type": "Region",
                "label": first["location"]["state"],
                "country": "US",
                "syntheticCoordinateDisclosure": "Listing coordinates are demo-only.",
            },
        )
        edges.append(
            {
                "id": _id("EDGE", f"{organization_id}|LOCATED_IN|{region_id}"),
                "source": organization_id,
                "target": region_id,
                "type": "LOCATED_IN",
                "evidenceRefs": sorted({item["provenance"]["source_ref"] for item in listings}),
            }
        )

    used_product_ids = {record["canonical_product_id"] for record in records}
    for product in taxonomy:
        if product["product_id"] in used_product_ids:
            nodes[product["product_id"]] = {
                "id": product["product_id"],
                "type": "Product",
                "label": product["name"],
                "category": product["category"],
                "taxonomySource": "data/reference/products.json",
            }

    certification_names = sorted(
        {assertion["name"] for record in records for assertion in record["certification_assertions"]}
    )
    cert_ids = {name: _id("CERT", name) for name in certification_names}
    for certification, cert_id in cert_ids.items():
        nodes[cert_id] = {
            "id": cert_id,
            "type": "CertificationAssertionType",
            "label": certification,
            "disclosure": "Node represents asserted text, not real-world verification.",
        }

    for record in records:
        relationship = "SUPPLIES" if record["record_type"] == "supply" else "DEMANDS"
        edges.append(
            {
                "id": _id("EDGE", f"{record['record_id']}|{relationship}"),
                "source": record["organization_entity_id"],
                "target": record["canonical_product_id"],
                "type": relationship,
                "recordId": record["record_id"],
                "quantityKg": record["quantity_kg"],
                "quantityBasis": record["quantity_basis"],
                "availableFrom": record["available_from"],
                "availableUntil": record["available_until"],
                "evidenceRefs": [record["provenance"]["source_ref"]],
            }
        )
        for assertion in record["certification_assertions"]:
            edges.append(
                {
                    "id": _id("EDGE", f"{record['record_id']}|ASSERTS|{assertion['name']}"),
                    "source": record["organization_entity_id"],
                    "target": cert_ids[assertion["name"]],
                    "type": "ASSERTS_CERTIFICATION",
                    "recordId": record["record_id"],
                    "evidenceStatus": assertion["evidenceStatus"],
                    "sourceRefs": [record["provenance"]["source_ref"]],
                    "verificationEvidenceRefs": (
                        [assertion["evidenceRef"]] if assertion["evidenceRef"] else []
                    ),
                    "realWorldVerified": False,
                }
            )

        if record["organization_type"] == "processor" and record["record_type"] == "supply":
            capability_id = _id(
                "CAP", f"{record['organization_entity_id']}|{record['canonical_product_id']}"
            )
            nodes[capability_id] = {
                "id": capability_id,
                "type": "Capability",
                "label": f"Processes {record['canonical_product_name']}",
                "form": record["attributes"].get("form", "unspecified"),
                "evidenceRefs": [record["provenance"]["source_ref"]],
            }
            edges.extend(
                [
                    {
                        "id": _id("EDGE", f"{record['organization_entity_id']}|HAS_CAPABILITY|{capability_id}"),
                        "source": record["organization_entity_id"],
                        "target": capability_id,
                        "type": "HAS_CAPABILITY",
                        "evidenceRefs": [record["provenance"]["source_ref"]],
                    },
                    {
                        "id": _id("EDGE", f"{capability_id}|PROCESSES|{record['canonical_product_id']}"),
                        "source": capability_id,
                        "target": record["canonical_product_id"],
                        "type": "PROCESSES",
                        "evidenceRefs": [record["provenance"]["source_ref"]],
                    },
                ]
            )

    for opportunity in opportunities:
        edges.append(
            {
                "id": _id("EDGE", opportunity["id"]),
                "source": opportunity["supply"]["organization_entity_id"],
                "target": opportunity["demand"]["organization_entity_id"],
                "type": "CANDIDATE_FOR",
                "opportunityId": opportunity["id"],
                "productId": opportunity["supply"]["canonical_product_id"],
                "fitScore": opportunity["fitScore"],
                "scoreSemantics": "relative ranking signal; not a probability",
                "status": opportunity["status"],
                "evidenceRefs": [
                    opportunity["supply"]["provenance"]["source_ref"],
                    opportunity["demand"]["provenance"]["source_ref"],
                ],
            }
        )

    type_counts: dict[str, int] = defaultdict(int)
    for node in nodes.values():
        type_counts[node["type"]] += 1
    relation_counts: dict[str, int] = defaultdict(int)
    for edge in edges:
        relation_counts[edge["type"]] += 1
    return {
        "nodes": sorted(nodes.values(), key=lambda node: (node["type"], node["label"])),
        "edges": edges,
        "nodeTypeCounts": dict(sorted(type_counts.items())),
        "relationshipCounts": dict(sorted(relation_counts.items())),
        "disclosure": "All organizations, listings, evidence references, and locations are fictional demo data.",
    }
