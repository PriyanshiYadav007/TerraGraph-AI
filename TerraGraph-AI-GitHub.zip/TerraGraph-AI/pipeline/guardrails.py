"""Policy gates that sit after ranking and before a human acts."""

from __future__ import annotations

from typing import Any


CONTROL_CATALOG = [
    {
        "id": "GR-001",
        "name": "Required certification assertion",
        "rule": "Block when a buyer-required certification is not asserted by the supplier.",
        "scope": "screening only; not legal or certification advice",
    },
    {
        "id": "GR-002",
        "name": "Certification evidence presence",
        "rule": "Route to evidence review when a required assertion lacks an evidence reference.",
        "scope": "demo evidence references are not live registry verification",
    },
    {
        "id": "GR-003",
        "name": "Commercial-field completeness",
        "rule": "Route to commercial review when either price is unknown.",
        "scope": "no price inference or quote is generated",
    },
    {
        "id": "GR-004",
        "name": "Availability overlap",
        "rule": "Block listings whose stated windows do not overlap.",
        "scope": "uses listing dates only",
    },
    {
        "id": "GR-005",
        "name": "Human decision boundary",
        "rule": "Never transact, contact, or certify automatically; every candidate requires human review.",
        "scope": "applies to every opportunity",
    },
]


def apply_guardrails(candidates: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    counts = {"review-ready": 0, "needs-evidence": 0, "blocked": 0}
    evaluated_controls = 0
    for candidate in candidates:
        supply, demand = candidate["supply"], candidate["demand"]
        assertions = {item["name"]: item for item in supply["certification_assertions"]}
        required = demand["required_certifications"]
        missing_assertions = [item for item in required if item not in assertions]
        missing_evidence = [
            item
            for item in required
            if item in assertions and assertions[item]["evidenceRef"] is None
        ]
        checks = [
            {
                "controlId": "GR-001",
                "result": "fail" if missing_assertions else "pass",
                "detail": (
                    f"Missing supplier assertion: {', '.join(missing_assertions)}"
                    if missing_assertions
                    else "All buyer-required certification names are asserted."
                ),
            },
            {
                "controlId": "GR-002",
                "result": "review" if missing_evidence else "pass",
                "detail": (
                    f"Evidence reference absent: {', '.join(missing_evidence)}"
                    if missing_evidence
                    else "Demo evidence references are present for required assertions."
                ),
            },
            {
                "controlId": "GR-003",
                "result": (
                    "review"
                    if supply["price_per_kg"] is None or demand["price_per_kg"] is None
                    else "pass"
                ),
                "detail": (
                    "At least one price is unknown; commercial confirmation required."
                    if supply["price_per_kg"] is None or demand["price_per_kg"] is None
                    else "Both listing prices are present and normalized to USD/kg."
                ),
            },
            {
                "controlId": "GR-004",
                "result": "pass" if candidate["featureVector"]["season_overlap"] > 0 else "fail",
                "detail": "Stated availability windows overlap."
                if candidate["featureVector"]["season_overlap"] > 0
                else "No stated availability-window overlap.",
            },
            {
                "controlId": "GR-005",
                "result": "review",
                "detail": "Human approval is required before outreach or commercial action.",
            },
        ]
        evaluated_controls += len(checks)
        if any(check["result"] == "fail" for check in checks):
            status = "blocked"
            status_label = "Blocked by guardrail"
        elif any(check["result"] == "review" for check in checks[:4]):
            status = "needs-evidence"
            status_label = "Needs evidence review"
        else:
            status = "review-ready"
            status_label = "Ready for human review"
        counts[status] += 1
        candidate["status"] = status
        candidate["statusLabel"] = status_label
        candidate["guardrails"] = checks
        candidate["humanDecisionRequired"] = True

    return candidates, {
        "controls": CONTROL_CATALOG,
        "counts": counts,
        "evaluationsRun": evaluated_controls,
        "automaticActionsTaken": 0,
        "disclosure": (
            "Rules screen synthetic listings only. They do not verify certificates, determine "
            "regulatory compliance, replace contracting diligence, or authorize transactions."
        ),
    }

