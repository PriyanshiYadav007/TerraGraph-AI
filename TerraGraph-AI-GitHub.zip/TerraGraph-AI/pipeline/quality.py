"""Actionable schema, duplication, completeness, and evidence findings."""

from __future__ import annotations

from typing import Any


def build_quality_findings(
    records: list[dict[str, Any]],
    quarantined: list[dict[str, Any]],
    org_merges: list[dict[str, Any]],
    product_audit: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    if quarantined:
        findings.append(
            {
                "id": "DQ-SCHEMA",
                "severity": "high",
                "title": f"{len(quarantined)} malformed rows quarantined",
                "detail": "Strict validation rejected invalid quantities or types before ML scoring.",
                "affectedRecords": [item["recordId"] for item in quarantined],
                "action": "Correct at source and re-run; no coercion is permitted.",
            }
        )
    if org_merges:
        findings.append(
            {
                "id": "DQ-ENTITY",
                "severity": "medium",
                "title": f"{len(org_merges)} organization alias pairs consolidated",
                "detail": "TF-IDF name similarity plus location and market-side constraints linked aliases.",
                "affectedRecords": sorted(
                    {
                        record_id
                        for item in org_merges
                        for record_id in (item["leftRecordId"], item["rightRecordId"])
                    }
                ),
                "action": "Confirm the merge before persisting a production golden record.",
            }
        )
    missing_price = [r["record_id"] for r in records if r["price_per_kg"] is None]
    if missing_price:
        findings.append(
            {
                "id": "DQ-PRICE",
                "severity": "medium",
                "title": f"{len(missing_price)} listing has no price",
                "detail": "Null is preserved; the model uses a neutral price feature and the guardrail routes review.",
                "affectedRecords": missing_price,
                "action": "Request a price basis and currency before commercial comparison.",
            }
        )
    missing_evidence = [
        r["record_id"]
        for r in records
        if any(item["evidenceRef"] is None for item in r["certification_assertions"])
    ]
    if missing_evidence:
        findings.append(
            {
                "id": "DQ-CERT",
                "severity": "high",
                "title": f"{len(missing_evidence)} certification assertion lacks evidence",
                "detail": "Certification text is treated as an assertion, not a verified fact.",
                "affectedRecords": missing_evidence,
                "action": "Collect evidence and verify it against the appropriate live registry.",
            }
        )
    unresolved = [item["recordId"] for item in product_audit if item["decision"] != "accepted"]
    findings.append(
        {
            "id": "DQ-TAXONOMY",
            "severity": "low" if not unresolved else "medium",
            "title": f"{len(product_audit) - len(unresolved)}/{len(product_audit)} product names resolved",
            "detail": "Raw names remain alongside canonical product IDs and resolution evidence.",
            "affectedRecords": unresolved,
            "action": "Review low-confidence mappings before candidate generation." if unresolved else "No action for this fixture.",
        }
    )
    return findings

