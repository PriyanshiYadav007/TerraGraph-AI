# Project response for David Lewis and Leigh

Hi David and Leigh,

Thank you for the opportunity to show you how I think. Rather than reuse an unrelated class project, I built **TerraGraph AI**, an independent synthetic prototype focused on the kind of fragmented food and agriculture data workflow described in the role.

## What problem was I trying to solve?

Food-system listings can arrive with inconsistent product names, mixed units, duplicate organization identities, missing commercial fields, and certification language that is easy to mistake for verified evidence. A simple similarity model can rank possible connections, but it can also make an unreliable record look authoritative.

I wanted to build a workflow that keeps both sides of that problem visible: use AI/ML where fuzzy matching and prioritization help, while keeping validation, provenance, hard rules, and people in control. TerraGraph AI converts synthetic supply and demand listings into normalized records, resolved entities, a typed knowledge graph, and explainable candidate opportunities. The dashboard lets a reviewer inspect why a candidate ranked where it did, which source records support it, and which deterministic checks passed, need evidence, or failed.

In the current reproducible snapshot, the pipeline scans 25 records, validates 23, quarantines 2, produces 13 opportunities, and builds 60 graph nodes with 88 edges. Ten opportunities are review-ready, two need evidence, one is blocked, and zero trigger an automatic commercial action.

## What constraints was I working within?

- **No real or proprietary marketplace data:** every organization, listing, label, evidence reference, and coordinate is fictional. I designed a consent-tagged synthetic fixture that could exercise the full pipeline without implying access to The Ryzosphere’s systems or data.
- **Very limited labeled data:** the ranker has only 48 manually curated synthetic review scenarios. I chose an interpretable baseline and report fixture-only out-of-fold metrics rather than implying production performance.
- **No live certification or logistics service:** certification text remains an assertion, distance is straight-line distance between fictional coordinates, and missing prices remain null.
- **Trust-sensitive outputs:** a match could eventually influence outreach or purchasing, so I separated model ranking from deterministic policy checks and required a human decision for every candidate.
- **Reproducibility:** the demo runs offline with fixed fixtures, seeds, ordering, timestamps, and output contracts. A second run must match the checked-in dashboard data exactly when dependency versions match.

I deliberately kept the scope narrow enough to finish and test end to end instead of simulating production integrations I could not validate.

## How did I use AI, and where did I work around or overrule it?

I used AI/ML inside the product in three places:

1. Character n-gram TF-IDF resolves product aliases and possible organization duplicates while retaining the original names, similarity scores, thresholds, and decisions.
2. Word/bi-gram TF-IDF measures language similarity within eligible supply-demand pairs.
3. A scikit-learn logistic-regression model ranks candidates across eight features and exposes the strongest standardized contributions for each result.

The model’s six-fold out-of-fold metrics on the small synthetic fixture are 0.983 ROC-AUC, 0.979 average precision, and 0.936 F1 at 0.5. I show those numbers for reproducibility, but the product clearly says they are not evidence of real-world accuracy and that a fit score is not a transaction probability.

I also used an AI coding assistant during implementation to speed up scaffolding and edge-case ideation. I treated its output as untrusted engineering input: I kept the data contract explicit, inspected the generated artifacts, and added behavioral tests around the failure modes that matter.

The places where I intentionally constrained or overruled AI are central to the project:

- malformed values and unknown schema fields are quarantined rather than guessed or coerced;
- an absent price stays null rather than being imputed as a quote;
- certification language remains a source assertion and is never promoted to verified fact;
- a hard certification mismatch blocks a candidate even if the model ranks it highly;
- no model, agent stage, or UI action can contact a party or approve a transaction.

## Links and anything else I would like to show

- **Five-minute walkthrough:** [VIDEO URL — replace before sending]
- **Repository:** [REPOSITORY URL — replace before sending]
- **Live demo (optional):** [LIVE DEMO URL — replace before sending, or remove this line]

The repository includes the synthetic inputs, complete Python pipeline, generated audit artifacts, interactive dashboard, behavioral tests, model card, limitations, and exact reproduction steps. I have also attached my resume to the email.

This is an independent technical demonstration with no affiliation to The Ryzosphere and no use of its proprietary data.

Best,

Priyanshi Yadav
