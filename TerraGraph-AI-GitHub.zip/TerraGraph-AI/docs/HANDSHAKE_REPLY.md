# Handshake reply draft

Hi David,

Thank you for getting back to me and for explaining what you and Leigh would like to see. I appreciated the open-ended prompt, so I built a focused project rather than sending an unrelated class assignment.

It is called **TerraGraph AI**—an independent synthetic demo that turns messy food and agriculture listings into validated entities, provenance-aware graph relationships, and explainable supply-demand candidates. I designed it so the ML can rank opportunities, but deterministic evidence checks and human review always control what happens next.

I’m also emailing you and Leigh with my answers, a five-minute walkthrough, the repository, and my resume attached.

- Video: [VIDEO URL — replace before sending]
- Repository: [REPOSITORY URL — replace before sending]
- Live demo: [LIVE DEMO URL — replace before sending, or remove this line]

Thank you again for the opportunity. I would be glad to walk through the design decisions and tradeoffs in an interview.

Best,

Priyanshi Yadav
