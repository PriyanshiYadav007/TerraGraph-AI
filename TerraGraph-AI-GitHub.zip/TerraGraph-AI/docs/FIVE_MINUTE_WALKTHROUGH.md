# TerraGraph AI: five-minute walkthrough

This is a recording plan, not a second presentation. Keep the dashboard and code full-screen, speak naturally, and let the working project carry the story.

## Before recording

1. From the repository root, generate and verify the snapshot:

   ```bash
   source .venv/bin/activate
   python -m pipeline.run
   python tests/test_pipeline.py
   npm test
   ```

2. Start the dashboard with `npm run dev` and open the URL printed in the terminal.
3. Set the browser to roughly 90% zoom so the opportunity list and evidence panel fit together.
4. Open these editor tabs in this order:

   - `pipeline/ranker.py`
   - `pipeline/guardrails.py`
   - `tests/test_pipeline.py`

5. Keep the successful test output visible in a terminal tab.
6. Close notifications, personal tabs, credentials, and unrelated files.
7. Start at the top of the dashboard with filters reset to **All**, **All products**, and **Min fit 0**.

## Exact recording sequence and spoken script

### 0:00–0:35 — Introduce the project

**On screen:** Dashboard at **Command center**. Keep the synthetic-demo badge and headline visible.

**Say:**

> Hi David and Leigh, I’m Priyanshi Yadav. After David’s note, I built TerraGraph AI: an evidence-aware workflow for turning fragmented food and agriculture listings into explainable supply-demand opportunities. This is an independent technical demo, not a copy of The Ryzosphere’s platform. It uses only fictional synthetic data and no company or proprietary information. The core problem I wanted to explore was how to use AI for fuzzy, messy data while keeping validation, evidence, and human judgment in control.

### 0:35–1:10 — Show the end-to-end result

**On screen:** Slowly scroll through the hero metrics and four-card metric strip. Point to **23/25**, **13 candidate matches**, the evidence-review count, and **0 autonomous actions** in the left rail.

**Say:**

> In this fixed snapshot, the pipeline scans 25 records. Strict validation accepts 23 and quarantines 2 before machine learning sees them. It resolves 21 organization entities and 10 canonical products, produces 13 candidate opportunities, and builds a graph with 60 nodes and 88 typed, provenance-aware edges. Ten candidates are ready for human review, two need more evidence, one is blocked, and the system takes zero automatic commercial actions.

### 1:10–2:00 — Explain a strong candidate

**On screen:** Click **Opportunities** in the left navigation. Click the first row, **Apple pomace powder** (`OPP-011`). Point first to the relative-fit score, then **Why it ranked here**, then the source references and hash.

**Say:**

> Here is the decision workbench. Candidate generation only pairs accepted listings that resolve to the same canonical product. An interpretable scikit-learn logistic-regression model then ranks each pair on eight visible features: language similarity, product agreement, distance, volume coverage, price fit, certification evidence fit, season overlap, and derived data quality. The score is deliberately labeled a relative ranking signal, not a deal probability. For each result I expose the strongest feature contributions, the original source references, and a raw-record hash so a reviewer can trace the recommendation.

### 2:00–2:55 — Show the model being overruled

**On screen:** Click the **Needs evidence** filter, then select **Pinto beans** (`OPP-008`). Point to `GR-002` and the missing USDA Organic evidence reference. Next click **Blocked**, select **Chickpeas** (`OPP-005`), and point to the failed `GR-001` check.

**Say:**

> This is where I intentionally limit AI. The pinto-bean candidate ranks well, but the certification assertion has no evidence reference, so a deterministic rule routes it to evidence review. The chickpea candidate is blocked because the buyer requires USDA Organic and the supplier does not assert it. These rules run after scoring, so a high model score cannot overrule them. Missing prices also stay null instead of being invented, and every candidate requires a person before outreach or any commercial action.

### 2:55–3:35 — Show the graph and agent audit

**On screen:** Click **Knowledge graph** in the left navigation and point to the typed supplier-product-buyer path. Then click **Agent trace** and press **Replay trace** once.

**Say:**

> The same accepted records become a typed graph of organizations, products, regions, processor capabilities, certification-assertion types, and candidate relationships. Evidence references stay on the relationships rather than becoming detached notes. The agent trace shows nine bounded stages from discovery through publishing, with input and output counts and a run hash. I call them agents because each stage has a focused job and an audit receipt; the runtime itself is deterministic, offline Python, with no external model or API call.

### 3:35–4:05 — Make data problems visible

**On screen:** Click **Review queue**. Point to the two quarantined rows, alias consolidation, missing-price finding, and missing-evidence finding.

**Say:**

> I treated bad data as review work instead of hiding it. Two rows with invalid quantities or types are isolated, organization aliases are surfaced for confirmation, the missing price remains visible, and certification text is treated only as a source assertion. That distinction matters in a domain where an unsupported claim could affect a real purchasing decision.

### 4:05–4:40 — Show the code behind the AI and controls

**On screen:** Switch to the editor. Open `pipeline/ranker.py`, use Find to jump to `FEATURES = [`, then Find again for `def train_ranker`. Open `pipeline/guardrails.py` and Find `def apply_guardrails`. Do not scroll through unrelated code.

**Say:**

> In the code, the model inputs are explicit and stable. The ranker is a standardized logistic regression trained on 48 manually curated synthetic scenarios and evaluated with six-fold out-of-fold predictions. The strong fixture metrics are disclosed in the model card, but I do not present them as production accuracy. In the guardrail module, the policy outcomes are ordinary inspectable rules, separate from the model, so they can be tested and changed without retraining it.

### 4:40–5:00 — Explain AI-assisted development and close

**On screen:** Open `tests/test_pipeline.py`. Use Find to show `test_schema_quarantines_bad_rows_without_coercion`, then `test_certification_guardrail_blocks_an_assertion_mismatch`. Switch to the terminal with the successful test output. End on the dashboard model card or project header.

**Say:**

> I also used an AI coding assistant to accelerate scaffolding and edge-case ideation. I did not let it define the trust boundary: I kept exact schemas, preserved nulls, checked the generated artifacts, and wrote behavioral tests for quarantine, provenance, score semantics, and guardrails. The main limitation is that everything is synthetic and the model is not externally validated. My next step would be permissioned connectors, live evidence verification, and human-reviewed outcome data. Thank you—I’d be glad to walk through any part in more depth.

## Final delivery check

- Replace every placeholder in the email with the real repository, video, and optional demo links.
- Open each link in a private/incognito window and confirm the reviewer can access it.
- Keep the repository visibility and video permissions appropriate for David and Leigh.
- Attach `Priyanshi_Resume__.pdf` to the email.
- Watch the exported video once for readable text, clear audio, and accidental personal information.
