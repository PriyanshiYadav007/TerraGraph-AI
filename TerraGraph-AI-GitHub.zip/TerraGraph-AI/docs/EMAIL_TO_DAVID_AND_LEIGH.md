# Email draft

**To:** David@theryzosphere.io; Leigh@theryzosphere.io

**Subject:** AI Agent Engineering project submission — Priyanshi Yadav

Hi David and Leigh,

Thank you for inviting me to share something I built. After reading the project prompt, I created **TerraGraph AI**, an independent synthetic prototype focused on trustworthy food and agriculture data workflows.

**What problem was I trying to solve?**

Food-system listings can be fragmented across sources, use inconsistent names and units, contain duplicate organizations, and mix certification assertions with actual evidence. I wanted to show how an AI-assisted workflow could turn those records into useful opportunities without hiding uncertainty. TerraGraph AI validates and normalizes listings, resolves entities, creates a typed knowledge graph, ranks supply-demand candidates, and shows the model drivers, source lineage, and hard-check results in an interactive dashboard.

In the current reproducible snapshot, it scans 25 records, accepts 23, quarantines 2 before ML, produces 13 candidate opportunities, and builds a graph with 60 nodes and 88 edges. Ten candidates are ready for human review, two need more evidence, one is blocked, and zero trigger an automatic commercial action.

**What constraints was I working within?**

I had no real marketplace data, live certification registry, or validated transaction outcomes, so every organization, listing, label, evidence reference, and coordinate is fictional synthetic data. The training fixture contains only 48 curated scenarios. I therefore chose an interpretable model, kept the pipeline offline and reproducible, preserved nulls and raw values, and stated the limitations directly instead of presenting the demo as production-ready.

**How did I use AI, and where did I overrule it?**

I used TF-IDF for fuzzy product and organization resolution and for product-language similarity. I used a scikit-learn logistic-regression model to rank eligible pairs across eight visible features, with per-candidate driver explanations. I also used an AI coding assistant to accelerate scaffolding and edge-case ideation, then checked its output against explicit contracts, generated artifacts, and behavioral tests.

I kept AI away from the final trust boundary. Invalid values are quarantined rather than guessed, missing prices remain null, certification text is never treated as verified without evidence, and deterministic policy rules run after the model. A missing required certification can block a high-scoring candidate, and every opportunity still requires a human decision.

**Links**

- Five-minute walkthrough: [VIDEO URL — replace before sending]
- Repository: [REPOSITORY URL — replace before sending]
- Live demo: [LIVE DEMO URL — replace before sending, or remove this line]

The repository includes the full pipeline, synthetic fixtures, generated audit artifacts, model card, tests, dashboard, and exact reproduction steps. I have attached my resume as requested.

This project is an independent technical demonstration. It is not affiliated with The Ryzosphere and uses no proprietary company data.

Thank you for your time and consideration. I would be excited to discuss the project and how I approached the tradeoffs.

Best,

Priyanshi Yadav

[LinkedIn](https://www.linkedin.com/in/priyanshi-yadav-61063b407/)

**Attachment:** `Priyanshi_Resume__.pdf`
