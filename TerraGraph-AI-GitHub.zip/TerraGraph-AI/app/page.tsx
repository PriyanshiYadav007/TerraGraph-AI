"use client";

import { useMemo, useState } from "react";
import dashboardData from "./dashboard-data.json";

const data = dashboardData;
type Opportunity = (typeof data.opportunities)[number];
const defaultOpportunity =
  data.opportunities.find((item) => item.status === "needs-evidence") ?? data.opportunities[0];

const featureNames: Record<string, string> = {
  semantic_similarity: "Language fit",
  product_exact: "Product agreement",
  distance_score: "Proximity",
  volume_coverage: "Volume coverage",
  price_fit: "Price fit",
  certification_fit: "Evidence fit",
  season_overlap: "Season overlap",
  evidence_quality: "Data quality",
};

function compactHash(value: string) {
  return `${value.slice(0, 8)}…${value.slice(-5)}`;
}

function titleCase(value: string) {
  return value.replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function statusCopy(status: string) {
  if (status === "review-ready") return "Review ready";
  if (status === "needs-evidence") return "Needs evidence";
  return "Blocked";
}

export default function Home() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [productFilter, setProductFilter] = useState("all");
  const [minScore, setMinScore] = useState(0);
  const [selectedId, setSelectedId] = useState(defaultOpportunity.id);
  const [visibleStages, setVisibleStages] = useState(data.agentTrace.length);
  const [replaying, setReplaying] = useState(false);

  const products = useMemo(
    () => [...new Set(data.opportunities.map((item) => item.product.name))].sort(),
    [],
  );

  const filtered = useMemo(
    () =>
      data.opportunities.filter(
        (item) =>
          (statusFilter === "all" || item.status === statusFilter) &&
          (productFilter === "all" || item.product.name === productFilter) &&
          item.fitScore >= minScore,
      ),
    [statusFilter, productFilter, minScore],
  );

  const selected: Opportunity =
    filtered.find((item) => item.id === selectedId) ??
    filtered[0] ??
    data.opportunities.find((item) => item.id === selectedId) ??
    data.opportunities[0];

  const maxDriverContribution = Math.max(
    ...selected.drivers.map((driver) => Math.abs(driver.contribution)),
    1,
  );

  async function replayRecordedTrace() {
    if (replaying) return;
    setReplaying(true);
    setVisibleStages(0);
    for (let index = 1; index <= data.agentTrace.length; index += 1) {
      await new Promise((resolve) => setTimeout(resolve, 180));
      setVisibleStages(index);
    }
    setReplaying(false);
  }

  function resetFilters() {
    setStatusFilter("all");
    setProductFilter("all");
    setMinScore(0);
  }

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <a className="brand" href="#overview" aria-label="TerraGraph AI home">
          <span className="brand-mark"><i /></span>
          <span><strong>TerraGraph</strong><small>AI opportunity intelligence</small></span>
        </a>

        <nav aria-label="Dashboard sections">
          <a aria-label="Command center" className="nav-item" href="#overview"><span>01</span><b>Command center</b></a>
          <a aria-label={`Opportunities, ${data.summary.opportunityCandidates} candidates`} className="nav-item" href="#opportunities"><span>02</span><b>Opportunities</b><em>{data.summary.opportunityCandidates}</em></a>
          <a aria-label="Knowledge graph" className="nav-item" href="#graph"><span>03</span><b>Knowledge graph</b></a>
          <a aria-label="Agent trace" className="nav-item" href="#pipeline"><span>04</span><b>Agent trace</b></a>
          <a aria-label={`Review queue, ${data.qualityFindings.length} findings`} className="nav-item" href="#quality"><span>05</span><b>Review queue</b><em>{data.qualityFindings.length}</em></a>
        </nav>

        <div className="sidebar-proof">
          <span className="proof-icon">0</span>
          <div><small>Autonomous actions</small><strong>Human control stays on.</strong></div>
          <p>Models prioritize candidates. Rules protect evidence boundaries. People make every decision.</p>
        </div>

        <div className="profile-row">
          <span className="avatar">PY</span>
          <span><strong>Priyanshi Yadav</strong><small>Project owner</small></span>
          <b>•••</b>
        </div>
      </aside>

      <section className="workspace" id="overview">
        <header className="topbar">
          <div>
            <p className="eyebrow">Food-system coordination workspace</p>
            <h1>Opportunity intelligence</h1>
          </div>
          <div className="top-actions">
            <span className="demo-badge"><i /> Synthetic demo</span>
            <span className="run-id">{data.meta.runId}</span>
            <button className="primary-button" type="button" onClick={replayRecordedTrace}>
              {replaying ? `Animating ${visibleStages}/${data.agentTrace.length}` : "Replay recorded trace"}<b>↗</b>
            </button>
          </div>
        </header>

        <section className="hero-grid">
          <article className="hero-card">
            <div className="hero-copy">
              <p className="lime-label">EVIDENCE-AWARE MATCHING · OFFLINE & REPRODUCIBLE</p>
              <h2>Find the strongest path.<br /><em>Keep the why.</em></h2>
              <p>TerraGraph turns messy, consent-tagged food and agriculture listings into validated entities, typed graph relationships, and explainable supply-demand candidates.</p>
              <div className="hero-stats">
                <span><b>{data.summary.validatedRecords}</b> valid records<small>of {data.summary.recordsScanned} scanned</small></span>
                <span><b>{data.summary.organizationEntities}</b> organizations<small>after {data.summary.organizationAliasesMerged} safe merges</small></span>
                <span><b>{data.summary.knowledgeGraphEdges}</b> graph edges<small>typed and provenance-aware</small></span>
              </div>
            </div>
            <div className="hero-score">
              <div
                className={`score-ring ${selected.status}`}
                style={{ background: `conic-gradient(var(--lime) 0 ${selected.fitScore}%, #35443a ${selected.fitScore}% 100%)` }}
              >
                <span><b>{selected.fitScore.toFixed(1)}</b><small>relative fit</small></span>
              </div>
              <p>Selected candidate</p>
              <strong>{selected.product.name}</strong>
              <small>Ranking signal, not a deal probability</small>
            </div>
          </article>

          <article className="decision-card">
            <div className="card-topline"><span>GUARDRAIL IN ACTION</span><b className={`status-pill ${selected.status}`}>{statusCopy(selected.status)}</b></div>
            <h3>A strong score cannot skip a hard check.</h3>
            <p>{selected.guardrails.find((item) => item.result !== "pass")?.detail ?? "All deterministic screening checks passed; human approval is still required."}</p>
            <div className="decision-path">
              <span><i className="supply-dot" />{selected.supplier.name}</span>
              <b>→</b>
              <span><i className="product-dot" />{selected.product.name}</span>
              <b>→</b>
              <span><i className="demand-dot" />{selected.buyer.name}</span>
            </div>
            <div className="decision-footer"><span>{selected.matchedQuantityDisplay} · {Math.round(selected.distanceKm).toLocaleString()} km</span><a href="#opportunities">Inspect evidence ↓</a></div>
          </article>
        </section>

        <section className="metric-strip" aria-label="Pipeline metrics">
          <article><span className="metric-index">01</span><div><small>Schema pass</small><strong>{data.summary.validatedRecords}/{data.summary.recordsScanned}</strong><p>{data.summary.quarantinedRecords} rejected, never coerced</p></div><i className="metric-bar"><b style={{ width: `${(data.summary.validatedRecords / data.summary.recordsScanned) * 100}%` }} /></i></article>
          <article><span className="metric-index">02</span><div><small>Candidate matches</small><strong>{data.summary.opportunityCandidates}</strong><p>{data.summary.reviewReady} ready for human review</p></div><i className="metric-bar"><b style={{ width: `${(data.summary.reviewReady / data.summary.opportunityCandidates) * 100}%` }} /></i></article>
          <article><span className="metric-index">03</span><div><small>Evidence review</small><strong>{data.summary.needsEvidence}</strong><p>{data.summary.blocked} blocked by a hard rule</p></div><i className="metric-bar amber"><b style={{ width: `${((data.summary.needsEvidence + data.summary.blocked) / data.summary.opportunityCandidates) * 100}%` }} /></i></article>
          <article><span className="metric-index">04</span><div><small>Derived data quality</small><strong>{Math.round(data.summary.meanDerivedDataQuality * 100)}%</strong><p>Completeness + provenance</p></div><i className="metric-bar aqua"><b style={{ width: `${data.summary.meanDerivedDataQuality * 100}%` }} /></i></article>
        </section>

        <section className="section-block" id="opportunities">
          <div className="section-heading">
            <div><p className="eyebrow">DECISION WORKBENCH</p><h2>Ranked opportunities, with the evidence attached.</h2></div>
            <p>Filter the shortlist, select a path, then inspect the model drivers and deterministic rules separately.</p>
          </div>

          <div className="workbench">
            <article className="opportunity-panel">
              <div className="filters">
                <div className="status-filters" aria-label="Filter by review status">
                  {[["all", "All"], ["review-ready", "Review ready"], ["needs-evidence", "Needs evidence"], ["blocked", "Blocked"]].map(([value, label]) => (
                    <button aria-pressed={statusFilter === value} className={statusFilter === value ? "active" : ""} type="button" key={value} onClick={() => setStatusFilter(value)}>{label}</button>
                  ))}
                </div>
                <label>Product<select value={productFilter} onChange={(event) => setProductFilter(event.target.value)}><option value="all">All products</option>{products.map((product) => <option key={product}>{product}</option>)}</select></label>
                <label className="range-control">Min fit <b>{minScore}</b><input type="range" min="0" max="95" step="5" value={minScore} onChange={(event) => setMinScore(Number(event.target.value))} /></label>
              </div>

              <div className="results-meta"><span>{filtered.length} of {data.opportunities.length} candidates</span><small>Sorted by relative model ranking</small></div>
              <div className="opportunity-list">
                {filtered.length ? filtered.map((item) => (
                  <button aria-pressed={selected.id === item.id} className={`opportunity-row ${selected.id === item.id ? "selected" : ""}`} type="button" key={item.id} onClick={() => setSelectedId(item.id)}>
                    <span className={`fit-tile ${item.status}`}><strong>{item.fitScore.toFixed(1)}</strong><small>FIT</small></span>
                    <span className="opportunity-copy"><small>{item.id} · {item.product.category}</small><strong>{item.product.name}</strong><span>{item.supplier.name} <b>→</b> {item.buyer.name}</span><em>{item.matchedQuantityDisplay} · {Math.round(item.distanceKm).toLocaleString()} km</em></span>
                    <span className={`row-status ${item.status}`}>{statusCopy(item.status)}</span>
                    <i>↗</i>
                  </button>
                )) : (
                  <div className="empty-state"><strong>No candidates match these filters.</strong><p>Lower the score or widen the status and product filters.</p><button type="button" onClick={resetFilters}>Reset filters</button></div>
                )}
              </div>
            </article>

            <article className="evidence-panel" aria-live="polite">
              <div className="evidence-header">
                <div><p className="eyebrow">MATCH EXPLANATION · {selected.id}</p><h3>{selected.product.name}</h3><span>{selected.route}</span></div>
                <span className={`status-pill ${selected.status}`}>{selected.statusLabel}</span>
              </div>

              <div className="path-rail">
                <div><span className="path-node supply">S</span><small>Supplier</small><strong>{selected.supplier.name}</strong><p>{selected.supplier.location} · {selected.supplier.quantityDisplay}</p></div>
                <i><b /></i>
                <div><span className="path-node product">P</span><small>Canonical product</small><strong>{selected.product.name}</strong><p>Raw: “{selected.product.supplierRawName}”</p></div>
                <i><b /></i>
                <div><span className="path-node demand">B</span><small>Buyer</small><strong>{selected.buyer.name}</strong><p>{selected.buyer.location} · {selected.buyer.quantityDisplay}</p></div>
              </div>

              <div className="explanation-grid">
                <div className="driver-block">
                  <div className="mini-heading"><h4>Why it ranked here</h4><span>standardized contributions</span></div>
                  {selected.drivers.map((driver) => (
                    <div className="driver" key={driver.feature}>
                      <div><span>{featureNames[driver.feature] ?? driver.label}</span><b>{driver.contribution > 0 ? "+" : ""}{driver.contribution.toFixed(2)}</b></div>
                      <i><b className={driver.effect === "raises rank" ? "positive" : "negative"} style={{ width: `${Math.max(6, (Math.abs(driver.contribution) / maxDriverContribution) * 100)}%` }} /></i>
                      <small>{driver.effect} · feature value {Math.round(driver.value * 100)}%</small>
                    </div>
                  ))}
                </div>

                <div className="guardrail-block">
                  <div className="mini-heading"><h4>Hard checks</h4><span>model cannot override</span></div>
                  {selected.guardrails.map((guardrail) => (
                    <div className={`guardrail ${guardrail.result}`} key={guardrail.controlId}>
                      <span>{guardrail.result === "pass" ? "✓" : guardrail.result === "fail" ? "×" : "!"}</span>
                      <div><strong>{guardrail.controlId} · {titleCase(guardrail.result)}</strong><p>{guardrail.detail}</p></div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="evidence-box">
                <div className="mini-heading"><h4>Certification assertions</h4><span>fictional demo evidence</span></div>
                <div className="cert-list">
                  {selected.supplierCertificationAssertions.length ? selected.supplierCertificationAssertions.map((certification) => (
                    <span className={certification.evidenceRef ? "evidence-present" : "evidence-missing"} key={certification.name}>
                      <i>{certification.evidenceRef ? "✓" : "!"}</i><b>{certification.name}</b><small>{certification.evidenceRef ?? "No evidence reference"}</small>
                    </span>
                  )) : <p>No certification assertion supplied for this candidate.</p>}
                </div>
                <div className="provenance-row"><span>Supplier source <code>{selected.supplier.sourceRef}</code></span><span>Buyer source <code>{selected.buyer.sourceRef}</code></span><span>Raw record hash <code>{compactHash(selected.provenance.supplierRawSha256)}</code></span></div>
              </div>
              <p className="score-disclosure">{selected.scoreLabel}. Every candidate still requires a human decision.</p>
            </article>
          </div>
        </section>

        <section className="insight-grid">
          <article className="graph-card" id="graph">
            <div className="card-heading"><div><p className="eyebrow">TYPED KNOWLEDGE GRAPH</p><h3>Selected relationship subgraph.</h3></div><span>Dataset totals: {data.summary.knowledgeGraphNodes} nodes · {data.summary.knowledgeGraphEdges} edges</span></div>
            <div className="graph-stage" role="img" aria-label={`Selected subgraph: ${selected.supplier.name} supplies ${selected.product.name}; ${selected.buyer.name} demands ${selected.product.name}; ${selected.supplier.name} is a candidate for ${selected.buyer.name}.`}>
              <div className="graph-orbit orbit-a" /><div className="graph-orbit orbit-b" />
              <div className="graph-node supplier-node"><span>S</span><b>{selected.supplier.name}</b><small>ORGANIZATION</small></div>
              <div className="graph-node product-node"><span>P</span><b>{selected.product.name}</b><small>PRODUCT</small></div>
              <div className="graph-node buyer-node"><span>B</span><b>{selected.buyer.name}</b><small>ORGANIZATION</small></div>
              <div className="graph-line line-one"><span>SUPPLIES</span></div><div className="graph-line line-two"><span>DEMANDS ←</span></div><div className="graph-line line-three"><span>CANDIDATE_FOR</span></div>
              <div className="graph-evidence-note">Source lineage: {selected.supplier.sourceRef} · {selected.buyer.sourceRef}</div>
            </div>
            <p className="graph-summary">{selected.supplier.name} supplies {selected.product.name}; {selected.buyer.name} demands it; the organizations form candidate {selected.id}.</p>
            <div className="graph-counts">
              {Object.entries(data.knowledgeGraph.nodeTypeCounts).map(([key, value]) => <span key={key}><b>{value}</b>{key}</span>)}
            </div>
          </article>

          <article className="trace-card" id="pipeline">
            <div className="card-heading"><div><p className="eyebrow">AUDITABLE AGENT WORKFLOW</p><h3>Every stage leaves a receipt.</h3></div><button type="button" onClick={replayRecordedTrace}>{replaying ? "Animating…" : "Replay trace"}</button></div>
            <div className="trace-list">
              {data.agentTrace.map((stage, index) => (
                <div className={`trace-row ${index < visibleStages ? "visible" : "pending"}`} key={stage.stageId}>
                  <span>{String(stage.stage).padStart(2, "0")}</span>
                  <div><strong>{stage.agent}</strong><p>{stage.operation}</p><small>{stage.decision}</small></div>
                  <i>{index < visibleStages ? "✓" : "·"}</i>
                </div>
              ))}
            </div>
            <div className="trace-footer"><span>Input SHA-256</span><code>{compactHash(data.meta.inputSha256)}</code><b>Pipeline: no external model/API calls</b></div>
          </article>
        </section>

        <section className="quality-section" id="quality">
          <div className="section-heading compact">
            <div><p className="eyebrow">HUMAN REVIEW QUEUE</p><h2>Data issues become work—not hidden assumptions.</h2></div>
            <p>{data.summary.quarantinedRecords} malformed records were isolated before ML; {data.summary.automaticActionsTaken} records triggered an automatic commercial action.</p>
          </div>
          <div className="quality-grid">
            {data.qualityFindings.map((finding, index) => (
              <article className={`quality-card ${finding.severity}`} key={finding.id}>
                <div><span>0{index + 1}</span><b>{finding.severity}</b></div>
                <h3>{finding.title}</h3><p>{finding.detail}</p>
                <small>Affected: {finding.affectedRecords.length ? finding.affectedRecords.join(", ") : "none"}</small>
                <strong>{finding.action}</strong>
              </article>
            ))}
          </div>
        </section>

        <section className="model-card">
          <div className="model-lead"><p className="lime-label">MODEL CARD · READ BEFORE INTERPRETING</p><h2>Useful for ranking.<br />Not ready for reality.</h2><p>{data.modelCard.labelDisclosure}</p></div>
          <div className="model-facts">
            <span><small>Algorithm</small><strong>{data.modelCard.algorithm}</strong></span>
            <span><small>Training fixture</small><strong>{data.modelCard.trainingRows} synthetic decisions</strong></span>
            <span><small>Validation</small><strong>6-fold out-of-fold</strong></span>
            <span><small>Autonomous actions</small><strong>{data.summary.automaticActionsTaken}</strong></span>
          </div>
          <div className="limitations"><h3>What this prototype does not claim</h3><ul>{data.modelCard.limitations.slice(0, 5).map((limitation) => <li key={limitation}>{limitation}</li>)}</ul></div>
        </section>

        <footer>
          <div className="footer-brand"><span className="brand-mark"><i /></span><span><strong>TerraGraph AI</strong><small>Built as an independent, synthetic technical demonstration.</small></span></div>
          <p>{data.meta.demoDisclosure}</p>
          <div><a href="#overview">Back to top ↑</a><span>Schema {data.meta.schemaVersion}</span></div>
        </footer>
      </section>
    </main>
  );
}
