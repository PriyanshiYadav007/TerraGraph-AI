import type { Metadata } from "next";
import { headers } from "next/headers";
import "./globals.css";

const title = "TerraGraph AI | Trusted Food-System Opportunity Intelligence";
const description =
  "A provenance-aware AI workflow for resolving fragmented food and agriculture data into explainable supply-demand matches.";

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host") ?? "localhost:3000";
  const protocol = requestHeaders.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  const socialImage = `${protocol}://${host}/og.png`;

  return {
    title,
    description,
    authors: [{ name: "Priyanshi Yadav" }],
    openGraph: {
      type: "website",
      title,
      description,
      images: [{ url: socialImage, width: 1731, height: 909, alt: "TerraGraph AI evidence-aware opportunity intelligence" }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [socialImage],
    },
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
