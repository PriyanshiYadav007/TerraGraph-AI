"""Behavioral tests for the offline TerraGraph data/ML pipeline."""

from __future__ import annotations

import json
from pathlib import Path
import sys
import tempfile
import unittest

REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from pipeline.ingest import ingest_records, load_json
from pipeline.models import SchemaError, validate_record
from pipeline.run import ROOT, build_dashboard


class TerraGraphPipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.dashboard, cls.artifacts = build_dashboard(ROOT)

    def test_schema_quarantines_bad_rows_without_coercion(self) -> None:
        result = ingest_records(ROOT / "data/raw/listings.json")
        self.assertEqual(result["manifest"]["rowsSeen"], 25)
        self.assertEqual(result["manifest"]["rowsAccepted"], 23)
        self.assertEqual(result["manifest"]["rowsQuarantined"], 2)
        reasons = {row["recordId"]: row["errors"] for row in result["quarantined"]}
        self.assertTrue(any("quantity must be greater" in error for error in reasons["BAD-001"]))
        self.assertTrue(any("numeric or null" in error for error in reasons["BAD-002"]))

    def test_nullable_price_is_valid_and_preserved(self) -> None:
        records = load_json(ROOT / "data/raw/listings.json")
        quinoa_request = next(row for row in records if row["record_id"] == "DEM-010")
        self.assertIs(validate_record(quinoa_request), quinoa_request)
        normalized = next(
            row for row in self.artifacts["normalized"] if row["record_id"] == "DEM-010"
        )
        self.assertIsNone(normalized["price_per_kg"])
        self.assertEqual(normalized["price_basis"], "not supplied")

    def test_unknown_schema_fields_are_rejected(self) -> None:
        record = load_json(ROOT / "data/raw/listings.json")[0]
        record["unexpected"] = "schema drift"
        with self.assertRaises(SchemaError) as raised:
            validate_record(record)
        self.assertIn("record has unknown keys: unexpected", raised.exception.errors)

    def test_availability_requires_date_only_values(self) -> None:
        record = load_json(ROOT / "data/raw/listings.json")[0]
        record["available_from"] = "2026-08-01T00:00:00Z"
        with self.assertRaises(SchemaError) as raised:
            validate_record(record)
        self.assertTrue(
            any("calendar date" in error for error in raised.exception.errors)
        )

    def test_capture_timestamp_requires_timezone(self) -> None:
        record = load_json(ROOT / "data/raw/listings.json")[0]
        record["source"]["captured_at"] = "2026-08-19T09:30:00"
        with self.assertRaises(SchemaError) as raised:
            validate_record(record)
        self.assertIn(
            "source.captured_at must include a UTC offset or Z",
            raised.exception.errors,
        )

    def test_non_finite_numbers_are_rejected(self) -> None:
        for field in ("quantity", "price_per_unit"):
            for value in (float("nan"), float("inf"), float("-inf")):
                with self.subTest(field=field, value=value):
                    record = load_json(ROOT / "data/raw/listings.json")[0]
                    record[field] = value
                    with self.assertRaises(SchemaError):
                        validate_record(record)

        record = load_json(ROOT / "data/raw/listings.json")[0]
        record["attributes"]["non_finite"] = float("nan")
        with self.assertRaises(SchemaError):
            validate_record(record)

        record = load_json(ROOT / "data/raw/listings.json")[0]
        record["quantity"] = 10**10000
        with self.assertRaises(SchemaError):
            validate_record(record)

    def test_duplicate_record_ids_are_quarantined(self) -> None:
        records = load_json(ROOT / "data/raw/listings.json")
        records.append(records[0])
        with tempfile.TemporaryDirectory() as directory:
            fixture = Path(directory) / "listings.json"
            fixture.write_text(json.dumps(records), encoding="utf-8")
            result = ingest_records(fixture)
        duplicate = next(
            row for row in result["quarantined"]
            if row["reason"] == "duplicate_record_id"
        )
        self.assertEqual(duplicate["recordId"], "SUP-001")
        self.assertEqual(result["manifest"]["rowsAccepted"], 23)

    def test_tfidf_resolution_keeps_raw_and_canonical_names(self) -> None:
        dashboard_record = next(
            row for row in self.dashboard["records"] if row["recordId"] == "SUP-004"
        )
        self.assertEqual(dashboard_record["productRaw"], "Reclaimed Oat Ingredient Flour")
        self.assertEqual(dashboard_record["productCanonical"], "Upcycled oat flour")
        self.assertEqual(dashboard_record["canonicalProductId"], "PROD-OAT-FLOUR")
        self.assertIn(
            dashboard_record["productResolution"]["method"],
            {"exact_normalized_alias", "tfidf_char_ngrams"},
        )

    def test_organization_aliases_are_conservatively_merged(self) -> None:
        merges = self.artifacts["organizationMerges"]
        pair_sets = [
            {merge["leftRecordId"], merge["rightRecordId"]} for merge in merges
        ]
        self.assertIn({"SUP-001", "SUP-011"}, pair_sets)
        self.assertIn({"DEM-001", "DEM-011"}, pair_sets)
        self.assertTrue(all("same_city_state" in row["evidence"] for row in merges))

    def test_real_sklearn_model_reports_out_of_fold_fixture_metrics(self) -> None:
        model = self.dashboard["modelCard"]
        self.assertEqual(model["implementation"], "scikit-learn")
        self.assertEqual(model["trainingRows"], 48)
        self.assertEqual(model["positiveRows"], 24)
        self.assertEqual(model["negativeRows"], 24)
        self.assertGreater(model["validation"]["rocAuc"], 0.9)
        self.assertGreater(model["validation"]["averagePrecision"], 0.9)
        self.assertIn("synthetic", model["labelDisclosure"])
        self.assertIn("not a probability", model["scoreDisclosure"])

    def test_fit_score_is_explainable_but_not_presented_as_probability(self) -> None:
        for opportunity in self.dashboard["opportunities"]:
            self.assertGreaterEqual(opportunity["fitScore"], 0)
            self.assertLessEqual(opportunity["fitScore"], 100)
            self.assertEqual(
                opportunity["scoreLabel"],
                "relative model ranking score — not a probability",
            )
            self.assertEqual(len(opportunity["drivers"]), 4)
            self.assertEqual(set(opportunity["featureVector"]), set(self.dashboard["modelCard"]["features"]))

    def test_certification_guardrail_blocks_an_assertion_mismatch(self) -> None:
        blocked = [item for item in self.dashboard["opportunities"] if item["status"] == "blocked"]
        self.assertEqual(len(blocked), 1)
        self.assertEqual(blocked[0]["buyer"]["recordId"], "DEM-012")
        certification_check = next(
            check for check in blocked[0]["guardrails"] if check["controlId"] == "GR-001"
        )
        self.assertEqual(certification_check["result"], "fail")
        self.assertEqual(self.dashboard["complianceGuardrails"]["automaticActionsTaken"], 0)

    def test_certification_assertion_is_not_claimed_as_real_verification(self) -> None:
        for record in self.dashboard["records"]:
            for assertion in record["certificationAssertions"]:
                self.assertFalse(assertion["realWorldVerified"])
        pinto = next(row for row in self.dashboard["records"] if row["recordId"] == "SUP-006")
        self.assertIsNone(pinto["certificationAssertions"][0]["evidenceRef"])
        cert_component = next(
            component for component in pinto["derivedDataQualityComponents"]
            if component["name"] == "cert_evidence_present"
        )
        self.assertEqual(cert_component["status"], "partial")

        assertion_edge = next(
            edge for edge in self.dashboard["knowledgeGraph"]["edges"]
            if edge.get("recordId") == "SUP-006"
            and edge["type"] == "ASSERTS_CERTIFICATION"
        )
        self.assertTrue(assertion_edge["sourceRefs"])
        self.assertEqual(assertion_edge["verificationEvidenceRefs"], [])

    def test_processor_capabilities_have_typed_processes_edges(self) -> None:
        graph = self.dashboard["knowledgeGraph"]
        capability_ids = {node["id"] for node in graph["nodes"] if node["type"] == "Capability"}
        processes_edges = [edge for edge in graph["edges"] if edge["type"] == "PROCESSES"]
        self.assertTrue(capability_ids)
        self.assertEqual({edge["source"] for edge in processes_edges}, capability_ids)
        self.assertTrue(all(edge["evidenceRefs"] for edge in processes_edges))

    def test_every_canonical_field_has_provenance_and_quantity_basis(self) -> None:
        for record in self.dashboard["records"]:
            self.assertIn("rawRecordSha256", record["source"])
            self.assertIn("quantity_kg", record["fieldLineage"])
            self.assertIn("canonical_product_id", record["fieldLineage"])
            self.assertIn("availability window", record["quantityBasis"])

    def test_checked_in_dashboard_matches_deterministic_build(self) -> None:
        checked_in = json.loads((ROOT / "public/data/dashboard.json").read_text(encoding="utf-8"))
        self.assertEqual(checked_in, self.dashboard)
        ui_copy = json.loads((ROOT / "app/dashboard-data.json").read_text(encoding="utf-8"))
        self.assertEqual(ui_copy, self.dashboard)
        second_dashboard, _ = build_dashboard(ROOT)
        self.assertEqual(second_dashboard, self.dashboard)


if __name__ == "__main__":
    unittest.main()
